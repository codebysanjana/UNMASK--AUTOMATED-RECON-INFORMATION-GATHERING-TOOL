# UNMASK — Local Reconnaissance Platform

Fresh standalone project: React/Vite frontend + Flask backend + SQLite database.

## Run on Windows
1. Extract the ZIP.
2. Install Python 3.10+ and Node.js 18+ if not already installed.
3. Double-click `start.bat`.
4. Open http://localhost:5173

Backend health: http://127.0.0.1:5000/api/health

## Features
- Registration, login, logout, password hashing, session cookies
- SQLite users, authorized targets, and scan history
- Explicit authorization confirmation before a target can be scanned
- Passive DNS, IP, WHOIS, TLS certificate, HTTP security headers, robots.txt, sitemap and availability checks
- PDF scan reports
- Nmap XML import for review only; the app does not run Nmap

Only assess domains you own or have explicit permission to assess. No exploitation, brute force, or active port scanning is included.
