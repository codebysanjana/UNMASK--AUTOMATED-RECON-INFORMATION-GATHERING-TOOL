@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul || (echo Install Python 3.10+ first.& pause & exit /b 1)
where node >nul 2>nul || (echo Install Node.js 18+ first.& pause & exit /b 1)
if not exist backend\.venv python -m venv backend\.venv
call backend\.venv\Scripts\activate.bat
pip install -r backend\requirements.txt
if not exist backend\.env copy backend\.env.example backend\.env >nul
if not exist frontend\node_modules (cd frontend & call npm install & cd ..)
start "UNMASK Backend" cmd /k "cd /d ""%~dp0backend"" && ""%~dp0backend\.venv\Scripts\python.exe"" app.py"
cd frontend
call npm run dev -- --host 127.0.0.1
