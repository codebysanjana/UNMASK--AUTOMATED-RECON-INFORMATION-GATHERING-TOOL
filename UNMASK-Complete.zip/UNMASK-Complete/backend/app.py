
import os,re,sqlite3,json,datetime,uuid,io,socket,ssl
from urllib.parse import urlparse
from functools import wraps
from flask import Flask,request,jsonify,session,send_file
from flask_cors import CORS
from werkzeug.security import generate_password_hash,check_password_hash
from dotenv import load_dotenv
import requests,dns.resolver,whois
from reportlab.pdfgen import canvas
load_dotenv()
HERE=os.path.dirname(os.path.abspath(__file__))
app=Flask(__name__); app.secret_key=os.getenv("SECRET_KEY","local-dev-secret-change-me")
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE="Lax")
CORS(app, supports_credentials=True, origins=[os.getenv("FRONTEND_ORIGIN","http://localhost:5173"),"http://127.0.0.1:5173"])
DB=os.path.join(HERE,os.getenv("DATABASE_PATH","unmask.db"))
def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
with db() as c:
 c.executescript("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE,password TEXT,created TEXT);
 CREATE TABLE IF NOT EXISTS targets(id INTEGER PRIMARY KEY,user_id INTEGER,domain TEXT,authorized INTEGER,created TEXT);
 CREATE TABLE IF NOT EXISTS scans(id TEXT PRIMARY KEY,user_id INTEGER,target_id INTEGER,status TEXT,results TEXT,created TEXT);""")
def auth(f):
 @wraps(f)
 def w(*a,**k):
  if not session.get("uid"): return jsonify(error="Please sign in"),401
  return f(*a,**k)
 return w
@app.before_request
def csrf_guard():
 if request.method in ("POST","PUT","DELETE") and request.path not in ("/api/login","/api/register") and session.get("uid"):
  if request.headers.get("X-CSRF-Token")!=session.get("csrf"): return jsonify(error="CSRF validation failed; refresh and retry"),403
def domain_name(v):
 v=(v or "").strip().lower()
 if "://" in v: v=urlparse(v).hostname or ""
 v=v.rstrip(".")
 return v if re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}",v) else None
@app.get("/api/health")
def health(): return jsonify(status="ok",service="UNMASK API")
@app.get("/api/csrf-token")
def csrf():
 session["csrf"]=session.get("csrf") or uuid.uuid4().hex
 return jsonify(csrf_token=session["csrf"])
@app.post("/api/register")
def register():
 d=request.get_json(silent=True) or {}; e=(d.get("email") or "").strip().lower(); p=d.get("password") or ""
 if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+",e) or len(p)<8: return jsonify(error="Enter a valid email and password of at least 8 characters"),400
 try:
  with db() as c: c.execute("INSERT INTO users(email,password,created) VALUES(?,?,?)",(e,generate_password_hash(p),datetime.datetime.utcnow().isoformat()))
 except sqlite3.IntegrityError: return jsonify(error="Email already registered"),409
 return jsonify(message="Account created")
@app.post("/api/login")
def login():
 d=request.get_json(silent=True) or {}; e=(d.get("email") or "").strip().lower()
 with db() as c: u=c.execute("SELECT * FROM users WHERE email=?",(e,)).fetchone()
 if not u or not check_password_hash(u["password"],d.get("password") or ""): return jsonify(error="Invalid email or password"),401
 session.clear(); session["uid"]=u["id"]; session["email"]=e; session["csrf"]=uuid.uuid4().hex
 return jsonify(user={"id":u["id"],"email":e},csrf_token=session["csrf"])
@app.get("/api/me")
@auth
def me(): return jsonify(user={"id":session["uid"],"email":session["email"]})
@app.post("/api/logout")
@auth
def logout(): session.clear(); return jsonify(message="Signed out")
@app.get("/api/dashboard")
@auth
def dashboard():
 with db() as c:
  t=c.execute("SELECT COUNT(*) n FROM targets WHERE user_id=?",(session["uid"],)).fetchone()["n"]
  s=c.execute("SELECT COUNT(*) n FROM scans WHERE user_id=?",(session["uid"],)).fetchone()["n"]
 return jsonify(targets=t,scans=s)
@app.get("/api/targets")
@auth
def targets():
 with db() as c: rows=c.execute("SELECT id,domain,authorized,created FROM targets WHERE user_id=? ORDER BY id DESC",(session["uid"],)).fetchall()
 return jsonify(targets=[dict(x) for x in rows])
@app.post("/api/targets")
@auth
def add_target():
 d=request.get_json(silent=True) or {}; domain=domain_name(d.get("domain"))
 if not domain: return jsonify(error="Enter a valid domain"),400
 if d.get("authorized") is not True: return jsonify(error="Confirm that you own or are authorized to assess this domain"),400
 with db() as c: cur=c.execute("INSERT INTO targets(user_id,domain,authorized,created) VALUES(?,?,1,?)",(session["uid"],domain,datetime.datetime.utcnow().isoformat()))
 return jsonify(id=cur.lastrowid,domain=domain,authorized=True),201
@app.delete("/api/targets/<int:tid>")
@auth
def del_target(tid):
 with db() as c: c.execute("DELETE FROM targets WHERE id=? AND user_id=?",(tid,session["uid"]))
 return jsonify(message="Target deleted")
def get(url): return requests.get(url,timeout=7,headers={"User-Agent":"UNMASK-Passive-Recon/1.0"},allow_redirects=True)
def recon(domain):
 r={"target":domain,"scanned_at":datetime.datetime.utcnow().isoformat()+"Z","dns":{},"ip_addresses":[],"whois":{},"ssl":{},"http":{},"resources":{},"availability":{}}
 for typ in ("A","AAAA","MX","NS","TXT"):
  try: r["dns"][typ]=[str(x) for x in dns.resolver.resolve(domain,typ,lifetime=4)]
  except Exception: r["dns"][typ]=[]
 r["ip_addresses"]=r["dns"]["A"]+r["dns"]["AAAA"]
 try:
  w=whois.whois(domain); r["whois"]={k:str(v)[:350] for k,v in w.items() if v}
 except Exception as e: r["whois"]={"status":"Unavailable","detail":str(e)[:120]}
 try:
  ctx=ssl.create_default_context()
  with socket.create_connection((domain,443),timeout=5) as s:
   with ctx.wrap_socket(s,server_hostname=domain) as z:
    cert=z.getpeercert(); r["ssl"]={"protocol":z.version(),"subject":str(cert.get("subject")),"issuer":str(cert.get("issuer")),"expires":cert.get("notAfter")}
 except Exception as e: r["ssl"]={"status":"Unavailable","detail":str(e)[:120]}
 try:
  x=get("https://"+domain); r["availability"]={"reachable":True,"status_code":x.status_code,"final_url":x.url}
  names=["Strict-Transport-Security","Content-Security-Policy","X-Frame-Options","X-Content-Type-Options","Referrer-Policy","Permissions-Policy"]
  r["http"]={"server":x.headers.get("Server"),"content_type":x.headers.get("Content-Type"),"security_headers":{n:x.headers.get(n) for n in names}}
  r["resources"]={"robots_txt":None,"sitemap_xml":None,"title":None}
  m=re.search(r"<title[^>]*>(.*?)</title>",x.text,re.I|re.S); r["resources"]["title"]=m.group(1).strip()[:180] if m else None
  for path,key in (("/robots.txt","robots_txt"),("/sitemap.xml","sitemap_xml")):
   try:
    q=get("https://"+domain+path)
    if q.status_code==200: r["resources"][key]=q.text[:2500]
   except Exception: pass
 except Exception as e: r["availability"]={"reachable":False,"error":str(e)[:150]}
 return r
@app.post("/api/scans")
@auth
def scan():
 d=request.get_json(silent=True) or {}
 if d.get("authorized") is not True: return jsonify(error="Authorization confirmation required"),400
 with db() as c: t=c.execute("SELECT * FROM targets WHERE id=? AND user_id=? AND authorized=1",(d.get("target_id"),session["uid"])).fetchone()
 if not t: return jsonify(error="Authorized target not found"),404
 result=recon(t["domain"]); sid=uuid.uuid4().hex
 with db() as c: c.execute("INSERT INTO scans VALUES(?,?,?,?,?,?)",(sid,session["uid"],t["id"],"completed",json.dumps(result),datetime.datetime.utcnow().isoformat()))
 return jsonify(id=sid,status="completed",results=result),201
@app.get("/api/scans")
@auth
def scans():
 with db() as c: rows=c.execute("SELECT id,target_id,status,created FROM scans WHERE user_id=? ORDER BY created DESC",(session["uid"],)).fetchall()
 return jsonify(scans=[dict(x) for x in rows])
@app.get("/api/scans/<sid>")
@auth
def detail(sid):
 with db() as c: x=c.execute("SELECT * FROM scans WHERE id=? AND user_id=?",(sid,session["uid"])).fetchone()
 if not x: return jsonify(error="Scan not found"),404
 d=dict(x); d["results"]=json.loads(d["results"]); return jsonify(d)
@app.get("/api/scans/<sid>/report.pdf")
@auth
def pdf(sid):
 with db() as c: x=c.execute("SELECT * FROM scans WHERE id=? AND user_id=?",(sid,session["uid"])).fetchone()
 if not x: return jsonify(error="Scan not found"),404
 data=json.loads(x["results"]); b=io.BytesIO(); p=canvas.Canvas(b); y=790
 p.setFont("Helvetica-Bold",17); p.drawString(45,y,"UNMASK Reconnaissance Report"); y-=30; p.setFont("Helvetica",10)
 lines=[f"Target: {data['target']}",f"Scanned: {data['scanned_at']}"]+[f"{k}: {json.dumps(v)[:130]}" for k,v in data.items() if k not in ("target","scanned_at")]
 for line in lines:
  if y<50: p.showPage(); y=790; p.setFont("Helvetica",9)
  p.drawString(45,y,line[:140]); y-=17
 p.save(); b.seek(0); return send_file(b,mimetype="application/pdf",as_attachment=True,download_name="UNMASK-report.pdf")
@app.post("/api/nmap/import")
@auth
def nmap_import():
 f=request.files.get("file")
 if not f or not f.filename.lower().endswith(".xml"): return jsonify(error="Upload an XML file"),400
 import xml.etree.ElementTree as ET
 try: root=ET.fromstring(f.read(1500000))
 except Exception: return jsonify(error="Invalid XML"),400
 hosts=[]
 for h in root.findall("host"):
  hosts.append({"addresses":[a.attrib.get("addr") for a in h.findall("address")],"status":h.find("status").attrib if h.find("status") is not None else {}})
 return jsonify(message="XML imported for review only; no active scan was run",hosts=hosts)
if __name__=="__main__": app.run(host="127.0.0.1",port=5000,debug=False)
